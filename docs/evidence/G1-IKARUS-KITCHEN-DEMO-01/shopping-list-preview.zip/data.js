// data.js
const STORAGE_KEY = 'shopping-list';

function loadItems() {
    const items = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    items.forEach(item => {
        if (!item.quantity) {
            item.quantity = 1;
        }
    });
    return items;
}

function saveItems(items) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}

function addItem(item, quantity) {
    const items = loadItems();
    items.push({ ...item, quantity });
    saveItems(items);
}

function deleteItem(index) {
    const items = loadItems();
    items.splice(index, 1);
    saveItems(items);
}

function toggleItem(index) {
    const items = loadItems();
    items[index].completed = !items[index].completed;
    saveItems(items);
}

function updateItemQuantity(index, quantity) {
    const items = loadItems();
    items[index].quantity = quantity;
    saveItems(items);
}
