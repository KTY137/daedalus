
2. **Open the Project in Your Browser**:

- Navigate to the `index.html` file in your browser to start using the app.

## Usage

1. **Adding Items**:
   - Enter the item name in the "Item" input field.
   - Enter the quantity in the "Quantity" input field.
   - Click the "Add Item" button to add the item to your list.

2. **Marking Items as Complete**:
   - Click on an item in the list to mark it as complete.

3. **Deleting Items**:
   - Click the "Delete" button next to an item to remove it from the list.

4. **Clearing the List**:
   - Click the "Clear List" button to remove all items from the list.

## Contributing

Contributions are welcome! Please read the [CONTRIBUTING.md](CONTRIBUTING.md) file for details on how to contribute to the project.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
