// utils.js
// Contains utility functions for the application.

/**
 * Checks if an element exists in the DOM.
 * @param {string} selector - The CSS selector for the element.
 * @returns {boolean} - True if the element exists, false otherwise.
 */
function elementExists(selector) {
    return document.querySelector(selector) !== null;
}

/**
 * Adds an event listener to an element.
 * @param {string} selector - The CSS selector for the element.
 * @param {string} event - The event type to listen for.
 * @param {function} callback - The callback function to execute.
 */
function addEventListener(selector, event, callback) {
    const element = document.querySelector(selector);
    if (element) {
        element.addEventListener(event, callback);
    }
}

/**
 * Removes an event listener from an element.
 * @param {string} selector - The CSS selector for the element.
 * @param {string} event - The event type to remove.
 * @param {function} callback - The callback function to remove.
 */
function removeEventListener(selector, event, callback) {
    const element = document.querySelector(selector);
    if (element) {
        element.removeEventListener(event, callback);
    }
}

/**
 * Creates a new element with the specified tag and class.
 * @param {string} tag - The tag name for the new element.
 * @param {string} className - The class name for the new element.
 * @returns {HTMLElement} - The newly created element.
 */
function createElement(tag, className) {
    const element = document.createElement(tag);
    element.className = className;
    return element;
}

/**
 * Appends a child element to a parent element.
 * @param {HTMLElement} parent - The parent element.
 * @param {HTMLElement} child - The child element to append.
 */
function appendChild(parent, child) {
    parent.appendChild(child);
}

/**
 * Removes a child element from a parent element.
 * @param {HTMLElement} parent - The parent element.
 * @param {HTMLElement} child - The child element to remove.
 */
function removeChild(parent, child) {
    parent.removeChild(child);
}

/**
 * Toggles the visibility of an element.
 * @param {string} selector - The CSS selector for the element.
 */
function toggleVisibility(selector) {
    const element = document.querySelector(selector);
    if (element) {
        element.style.display = element.style.display === 'none' ? 'block' : 'none';
    }
}
