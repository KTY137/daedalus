"""Kitchen-owned structural evaluator (generated; the builder must not edit it)."""
import html.parser
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parents[1]
IDS = ["item-input"]
FUNCTIONS = ["addItem"]
KEYS = []


def _read(name):
    path = ROOT / name
    assert path.is_file(), f"{name} is missing"
    return path.read_text(encoding="utf-8")


class _Shell(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.scripts, self.styles, self.ids = [], [], [], set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append(tag)
        if tag == "script" and attrs.get("src"):
            self.scripts.append(attrs["src"])
        if tag == "link" and attrs.get("rel", "").lower() == "stylesheet" and attrs.get("href"):
            self.styles.append(attrs["href"])
        if attrs.get("id"):
            self.ids.add(attrs["id"])


def _shell():
    parser = _Shell()
    parser.feed(_read("index.html"))
    return parser


def test_index_is_a_complete_html_document():
    shell = _shell()
    for tag in ("html", "head", "body"):
        assert tag in shell.tags, f"<{tag}> missing"
    assert "title" in shell.tags or "h1" in shell.tags


def test_referenced_assets_exist_and_are_local():
    shell = _shell()
    for ref in shell.scripts + shell.styles:
        assert not ref.startswith(("http://", "https://", "//")), f"external asset {ref}"
        assert (ROOT / ref.split("?")[0]).is_file(), f"missing asset {ref}"
    assert shell.scripts, "index.html loads no script"


def test_app_script_uses_local_storage_and_has_no_network_calls():
    shell = _shell()
    js = "\n".join(_read(ref.split("?")[0]) for ref in shell.scripts)
    assert "localStorage" in js
    assert not re.search(r"\bfetch\(|XMLHttpRequest|WebSocket", js), "network calls are not allowed"
    assert not re.search(r"https?://", js.replace("http://127.0.0.1", "")), "external URLs are not allowed"


def test_shared_contract_ids_are_present():
    shell = _shell()
    js = "\n".join(_read(ref.split("?")[0]) for ref in shell.scripts)
    missing = [i for i in IDS if i not in shell.ids and f'"{i}"' not in js and f"'{i}'" not in js and f"#{i}" not in js]
    assert not missing, f"contract ids missing: {missing}"


def test_shared_contract_functions_are_defined():
    shell = _shell()
    js = "\n".join(_read(ref.split("?")[0]) for ref in shell.scripts)
    missing = [f for f in FUNCTIONS if not re.search(r"\b" + re.escape(f) + r"\b", js)]
    assert not missing, f"contract functions missing: {missing}"


def test_readme_explains_how_to_run():
    readme = _read("README.md").lower()
    assert "http.server" in readme or "open" in readme or "öffne" in readme or "run" in readme or "start" in readme
