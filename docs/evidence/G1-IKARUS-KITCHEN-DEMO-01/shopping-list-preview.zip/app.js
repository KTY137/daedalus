const STORAGE_KEY = 'shopping-list';

document.addEventListener('DOMContentLoaded', () => {
    loadItems();
    document.getElementById('item-form').addEventListener('submit', (event) => {
        event.preventDefault();
        addItem();
    });
    document.getElementById('item-input').addEventListener('input', (event) => {
        event.target.setCustomValidity('');
    });
    document.getElementById('quantity-input').addEventListener('input', (event) => {
        event.target.setCustomValidity('');
    });
    document.getElementById('item-list').addEventListener('click', (event) => {
        const button = event.target.closest('.delete-item');
        if (button) {
            deleteItem(button);
            return;
        }
        // Labels use the checkbox's native behavior. Clicking empty row space
        // also toggles it, without toggling label clicks twice.
        const item = event.target.closest('li.item');
        if (item && !event.target.closest('label')) {
            toggleItem(item);
        }
    });
    document.getElementById('item-list').addEventListener('change', (event) => {
        if (event.target.matches('input[type="checkbox"]')) {
            const item = event.target.closest('li.item');
            item.classList.toggle('completed', event.target.checked);
            saveItems();
        }
    });
    document.getElementById('clear-list-btn').addEventListener('click', clearList);
});

function addItem() {
    const input = document.getElementById('item-input');
    const quantityInput = document.getElementById('quantity-input');
    const name = input.value.trim();
    const quantity = Number(quantityInput.value);
    input.setCustomValidity(name ? '' : 'Enter an item name.');
    quantityInput.setCustomValidity(
        quantityInput.value !== '' && Number.isSafeInteger(quantity) && quantity >= 1
            ? '' : 'Enter a whole number of at least 1.'
    );
    if (!document.getElementById('item-form').reportValidity()) {
        return;
    }
    appendItem(name, quantity, false);
    input.value = '';
    quantityInput.value = '1';
    document.getElementById('list-status').textContent = `${name} added.`;
    saveItems();
    input.focus();
}

function appendItem(name, quantity, completed) {
    const item = document.createElement('li');
    item.className = 'item';
    item.classList.toggle('completed', completed);
    item.dataset.name = name;
    item.dataset.quantity = String(quantity);

    const label = document.createElement('label');
    label.className = 'item-main';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = completed;
    const text = document.createElement('span');
    text.className = 'item-text';
    text.textContent = `${name} x ${quantity}`;
    label.append(checkbox, text);

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'delete-item';
    button.textContent = 'Delete';
    button.setAttribute('aria-label', `Delete ${name}`);
    item.append(label, button);
    document.getElementById('item-list').appendChild(item);
}

function toggleItem(item) {
    const completed = item.classList.toggle('completed');
    item.querySelector('input[type="checkbox"]').checked = completed;
    saveItems();
}

function deleteItem(button) {
    const item = button.closest('li.item');
    document.getElementById('list-status').textContent = `${item.dataset.name} deleted.`;
    item.remove();
    saveItems();
}

function clearList() {
    document.getElementById('item-list').replaceChildren();
    document.getElementById('list-status').textContent = 'List cleared.';
    saveItems();
}

function loadItems() {
    let items;
    try {
        items = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch (_error) {
        document.getElementById('list-status').textContent = 'The saved list could not be read.';
        return;
    }
    if (!Array.isArray(items)) {
        return;
    }
    items.forEach((item) => {
        if (!item || typeof item.text !== 'string') {
            return;
        }
        // Old entries kept their displayed quantity only in the text suffix.
        const legacy = /^(.*) x ([1-9]\d*)$/.exec(item.text);
        const storedQuantity = Number(item.quantity ?? (legacy ? legacy[2] : 1));
        const quantity = Number.isSafeInteger(storedQuantity) && storedQuantity >= 1 ? storedQuantity : 1;
        const name = typeof item.name === 'string' ? item.name : (legacy ? legacy[1] : item.text);
        if (name.trim()) {
            appendItem(name, quantity, item.completed === true);
        }
    });
}

function saveItems() {
    const items = Array.from(document.querySelectorAll('#item-list .item')).map((item) => ({
        text: `${item.dataset.name} x ${item.dataset.quantity}`,
        name: item.dataset.name,
        quantity: Number(item.dataset.quantity),
        completed: item.classList.contains('completed')
    }));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}
