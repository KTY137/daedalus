from pathlib import Path
import hashlib
import json
import sys

repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo))
from tools.mutation_score import Mutation, pytest_runner, score

out = repo / 'runs/g1-ignition-03-20260908'
rel = 'daedalus/ignition/gate1.py'
selection = ['tests/ignition/test_gate1_root_admission.py']
specs = [
    ('A11-reset-before-admission',
     '    layout = _admit_ignition_layout(fixture_root, receipt_root, workspace, source_tree_store_root)',
     '    _reset_evidence_store(Path(receipt_root) / SESSION_MISSION_ID / "store")\n    layout = _admit_ignition_layout(fixture_root, receipt_root, workspace, source_tree_store_root)',
     'test_forbidden_missing_roots_are_compared_without_debris_masking'),
    ('A11-admit-contains-direction',
     'if relation is not PlannedRootRelation.DISJOINT:',
     'if relation not in (PlannedRootRelation.DISJOINT, PlannedRootRelation.CONTAINS):',
     'test_forbidden_missing_roots_are_compared_without_debris_masking'),
    ('A11-omit-derived-store-head-admission',
     'derived.append((_admit_ignition_path(evidence / name, f"evidence {name}"), f"evidence {name}"))',
     'derived.append((evidence / name, f"evidence {name}"))',
     'test_wrong_derived_directory_type_refuses_before_reset'),
    ('A11-bypass-direct-preparation-guard',
     '    _require_separate_from_existing(repo, "preparation destination", fixture, "source")\n    _require_separate_from_existing(repo, "preparation destination", installation, "installation")',
     '    # MUTANT: direct caller bypasses topology admission',
     'test_direct_preparation_refuses_before_copy'),
    ('A9-reselect-default-workspace-after-admission',
     '    scratch = layout.workspace',
     '    scratch = _prospective_ignition_workspace() if layout.automatic_workspace else layout.workspace',
     'test_default_workspace_allocates_exactly_the_admitted_leaf'),
]
paths = [rel, 'daedalus/primary_tree.py', selection[0]]
hashes = {p: hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
mutations = []
for name, before, after, expected in specs:
    assert (repo/rel).read_text(encoding='utf-8').count(before) == 1, name
    mutations.append(Mutation.patch(rel, before, after, id=name, rule=name, expect_test=expected))
(out/'root-mutations-frozen.json').write_text(json.dumps(dict(
    source_sha256=hashes, selection=selection, timeout_s=120,
    mutations=[dict(id=n,before=b,after=a,expected=e) for n,b,a,e in specs]), indent=2)+'\n',encoding='utf-8')
counter = 0
def runner(root, tests, timeout):
    global counter
    current = counter
    counter += 1
    plugin = root/'_g1_root_mutation_proof.py'
    plugin.write_text('''from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
def pytest_sessionfinish(session,exitstatus):
    from daedalus.ignition import gate1
    path=Path(gate1.__file__).resolve()
    Path("_g1_loaded_source.json").write_text(json.dumps({"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}),encoding="utf-8")
''',encoding='utf-8')
    result = pytest_runner(root, [*tests, '-p', '_g1_root_mutation_proof'], timeout)
    proof = json.loads((root/'_g1_loaded_source.json').read_text(encoding='utf-8'))
    (out/f'root-mutations-run-{current}.log').write_text(result.output,encoding='utf-8')
    (out/f'root-mutations-run-{current}-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
    assert Path(proof['path']) == (root/rel).resolve()
    assert proof['sha256'] == hashlib.sha256((root/rel).read_bytes()).hexdigest()
    return result

report = score(repo, rel, selection, mutations=mutations, timeout=120, runner=runner)
report['shared_sources_unchanged'] = all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
(out/'root-mutations-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('baseline_green','verdict','mutation_score','shared_sources_unchanged')}))
print([(r['id'],r['status']) for r in report['results']])
