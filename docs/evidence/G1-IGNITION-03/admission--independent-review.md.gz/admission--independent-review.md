# G1-IGNITION-03 independent review

Classification: ALIGNED. Reviewed the full activated packet against Master Plan
Revision 13 (SHA256 04e8cbf9441134e22b97fe1cb5e7ebcbcfedac64cda2f3e4e5086d82bb628639).
No shared production or test file was edited by this reviewer. The Python probe
helpers reside only in a task-owned TEMP directory, outside the source census.

## Reviewed source

- `daedalus/ignition/gate1.py`: SHA256
  `373f7dce0199b77bf8d1a3744df0f67dd37c18a32ceaf98537825d6118c73d5b`.
- `daedalus/primary_tree.py`: SHA256
  `64350c34aca3dfe015ba1f9a4f8c2b85fb00aa3330643c3cc448f586e194c62a`.
- Canonical comparator tests reviewed at SHA256
  `b3f41e34820352545826828d61d7168f267a6448b678a30b8ffdce86d299dae1`.

No blocking source defect found in this snapshot. Admission precedes reset,
store construction, temp allocation, evaluator dispatch and direct copy.
Raw existing components are inspected before resolution; Windows namespace,
drive-relative, reserved-name, ADS and trailing-dot/space spellings refuse.
Known derived roots and single-link receipt type are checked. Geometry remains
in the canonical module. Its existing public predicates are unchanged, while
the additive relation retains prospective tails and distinguishes the bounded
receipt-file mode from directory roots. Valid nested/default CAS paths survive.
The actual workspace is the immutable layout's selected path, and automatic
allocation is exclusive. These are entry-time checks, not TOCTOU protection or
complete hardlink defense for arbitrary old store contents.

Before production editing, review identified and the parent froze: the existing
regular receipt/comparator type mismatch; missing-root ancestor discriminators
that cannot be masked by nonempty-workspace refusal; isolated CAS-containing-
source refusal; raw redirect before `..`; reserved Windows components; empty
explicit paths; known `E/blobs` and `E/locators`; and unsafe/absent configured
temp parents without fallback. Negative baseline results remain separate from
the new passing behavior.

## Independent measurements

`independent-root-probe.json` records **17 passed, 1 unmeasured**, exit 0.
This public-door first-write probe used unique TEMP-owned fixtures and stopped
before candidate execution. All sentinel path sets, identities, link counts
and bytes remained unchanged. Both ordinary-receipt/default-CAS and strict
nested-CAS positives reached the first writer. Real receipt hardlink refusal
passed. The sole unmeasured case is a real directory symlink, denied by Windows
privilege error 1314; it is not reported as a passing alias case. The owned
fixture tree was removed in verified cleanup. Before/after source hashes match
in `independent-root-probe-source.json`; stderr is empty.

`independent-allocation-probe.json` records **passed**, exit 0. It observed a
real scratch `mkdir` after layout admission: exactly one UUID selection, exactly
the admitted path, `mode=0700`, and `exist_ok=False`. Protected source bytes and
the reviewed gate1 hash stayed unchanged; cleanup removed the owned TEMP tree.
This is allocation-only evidence with evaluator metadata stubbed, not a real
ignition or evaluator run. Stderr is empty.

Frozen helpers under
`C:/Users/Administrator/AppData/Local/Temp/daedalus-g1-ignition-03-review-8448dadd50c845e0b1b900f267947b2e/`:

- `independent_root_probe.py`: SHA256
  `f405d373699bcc49b65243cbbff950fb6e7e8aa69b263cbe1e70fd7204a19478`.
- `independent_allocation_probe.py`: SHA256
  `ecc445562760a5f81526b80b612996c3ab946f4116e6eb403164d7fb845e478a`.

## Reviewed P9 mutation evidence

Read `runs/ignition-roots-20260908/primary-tree-p9-{frozen,results}.json` and the
four retained run logs. Baseline and all mutants used the full canonical fence
file with the same 120-second budget in `tools.mutation_score`'s Sandbox.
Every session-finish marker identifies that Sandbox module and its exact
source SHA, matching the retained mutated bytes. The three targeted mutations
were caught by the intended meaningful assertions:

| Mutation | Newly failing tests | Discriminator |
| --- | ---: | --- |
| Drop prospective tails | 33 | Missing siblings/default layout become wrongly equal. |
| Drop contains direction | 13 | Parent/child relation loses its reverse direction. |
| Admit uninspectable ground | 15 | Failed resolution/inspection wrongly becomes disjoint. |

The builder's retained baseline is 65 passed and 2 actual symlink-platform skips.
Shared source/test hashes stayed unchanged through these isolated mutations.

This note reviews the source and bounded evidence above. The parent's complete
shipped-door suite, A11 mutation evidence and separate Linux alias measurements
remain their respective acceptance records; this note does not claim Gate 1
closure or same-Attempt recovery.

## Final A11/A9 and affected-suite evidence review

Reviewed `root-mutations-frozen.json`, `root-mutations-results.json`, all six
`root-mutations-run-N-source.json` receipts and their logs. The complete frozen
A-file selection ran with the same 120-second budget for baseline and each
mutation. Baseline: **89 passed, 8 explicit platform skips**. All five mutants
were caught, with no survivor, inapplicable or inconclusive mutation:

| Mutation | Newly failing tests | Specific observed discriminator |
| --- | ---: | --- |
| Evidence reset before admission | 71 | Invalid layouts reach the first-write tripwire, including missing-root cases without debris. |
| Permit the contains relation | 4 | Missing W containing missing R/C reaches the writer; reverse containment is independently exercised. |
| Omit derived evidence-head admission | 2 | Existing regular files at `E/blobs` and `E/locators` escape early refusal. |
| Bypass direct preparation topology guard | 2 | Missing destinations inside source/installation reach copy. |
| Reselect default scratch after admission | 1 | The allocation target differs from the exact previously admitted leaf. |

Independently reapplied each frozen byte replacement **in memory only** to the
reviewed gate1 bytes. Every replacement occurs exactly once, and every resulting
SHA256 matches its session's loaded-source proof. All six proofs name the same
canonical mutation Sandbox, not the shared checkout. The gate1, primary-tree and
full A-test hashes still match the frozen inputs. The retained results report
unchanged shared source/test bytes. The independent hash/XML cross-check is
recorded in `independent-final-mutation-audit.json`.

Reviewed the two rejected initial control attempts separately. No score from
either was accepted. The retained second control proof identifies the Sandbox
module and the correct unmutated SHA; its tests themselves passed. The corrected
record explicitly supersedes the initial import-resolution hypothesis: the
parent compared a raw `ADMINI~1` expected path with the observed resolved
`Administrator` spelling. Resolving the expected path as well preserves the
same-object check and the exact SHA check. The retained evidence does not
establish an out-of-Sandbox import or a product defect.

The affected-suite XML contains **234 passed, 1 failed, 10 skipped** at unchanged
production hashes. The single failure is exactly the obsolete expected text
`must not already exist` versus the new early `ignition workspace must be empty`
in `test_crash_between_rename_writes_leaves_no_evaluable_candidate`. Reviewed
the test correction: only that expected message changed in this row; the real
second-rename crash, two-attempt count, source preservation, absence of an
evaluable candidate, debris refusal and fresh-workspace digest/replay assertions
remain. The full corrected row then passed, **1 passed in 34.78 seconds**, with
no product edit. The original red XML/log remains retained; it is not relabeled
as an entirely green affected-suite invocation.

Also reviewed the separately exposed Linux prose correction in the old
`planned_overlap_reason` test. It enumerates only the existing definite
contains verdicts; disjoint, unknown and `None` still fail. This is a test
contract correction, with production predicates unchanged. Linux execution and
environment results remain the Linux owner's separate retained record.

**Final bounded conclusion:** no additional product defect or hidden Windows
acceptance discriminator gap found for the frozen early-root-admission claim.
The eight A-file platform skips and the independent real-symlink limitation
remain explicit; this review does not substitute for the pending Linux alias
measurements, later same-Attempt recovery, or Gate-1 scientific closure.

## Final Linux platform verification

The Linux alias measurements are now available and reviewed independently in
`runs/ignition-roots-20260908/linux/final/`: JUnit, raw log, source manifest,
platform/summary/container-result JSON, image/container inspection and cleanup.
JUnit contains **158 cases: 146 passed, 12 skipped, zero failures/errors**.
Every skip is an explicit Windows-only spelling, case or junction discriminator.
The real directory-symlink comparator, all seven redirected derived-path cases,
raw symlink followed by `..`, and the real receipt-hardlink case actually ran
and passed. The skipped Linux junction row is unmeasured there, not a failure;
the corresponding Windows junction controls were already measured separately.

Manifest and platform records bind the unchanged production hashes listed at
the start of this review. They bind the full A suite to
`ca80daa2e611d9bba4fb823a3823927f58826174ce36695630fd08784e671e1b`, and the
legacy-prose-corrected fence test to
`e52fc209012568387f85cfb8fe6d7dfccb8db9ef854d76bbe43e9702988663df`.
All **5,090** snapshot files matched before execution and remained unchanged
afterwards. The pinned image is
`sha256:e033af0116e49682d99b9f22e9e7267d5bb8a142f8fbba42d7517f54e5192d33`.
Inspection confirms read-only container root, network `none`, user `1000:1000`,
one writable evidence mount and a **4-GiB `/tmp` tmpfs**; that tmpfs size is not
a container RAM limit. The run exited 0 without timeout and the exited
container was removed. This is Linux path-admission evidence, not OCI runtime
admission or a new sandbox-security claim.

The retained exact-bf69 Linux baseline has **23 passed and 1 failure** in the old
contains-message assertion. The platform wording closure records the bounded
test-only correction and unchanged ASTs for all 17 prospective helpers/tests;
the existing production predicate remains unchanged. Final Windows fence
revalidation is 65 passed and 2 explicit symlink-privilege skips. Initial Linux
harness/environment failures remain separately retained.

No remaining cross-platform alias-execution gap or product blocker was found
for this packet's frozen entry-time claim. The parent's final combined Windows
affected-suite rerun remains a separate acceptance receipt; the earlier
234-pass/1-message-failure run above remains honestly labeled.
