from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
out = root/'docs/evidence/G1-IGNITION-03'
out.mkdir(parents=True,exist_ok=True)
run = root/'runs/g1-ignition-03-20260908'
final = json.loads((run/'final-affected-result.json').read_text(encoding='utf-8'))
assert final['exit_code']==0 and final['changed_source_files']==[]
def junit(path):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    return dict(total=len(cases),passed=sum(not any(c.find(tag) is not None for tag in ('failure','error','skipped')) for c in cases),
                failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases),
                skipped=sum(c.find('skipped') is not None for c in cases))
sources = [
    'daedalus/ignition/gate1.py','daedalus/primary_tree.py',
    'tests/ignition/test_gate1_root_admission.py','tests/ignition/test_voltage_ignition_faults.py',
    'tests/test_primary_tree_fence.py','tests/contracts/test_import_scc_hierarchy.py',
    'tests/contracts/test_work_packet_index.py','experiments/forest_v2/s02_types/test_external_corpora.py',
]
manifest = dict(schema_version=1,packet_id='G1-IGNITION-03',classification='ALIGNED',
    base_revision='bf69e7195eba4d2c161e61aaead6aaa5695ab5bc',
    outcome='LOCAL_ACCEPTANCE_PASSED_CI_PENDING',
    plan_sha256=hashlib.sha256((root/'docs/IKARUS_ARIADNE_MASTER_PLAN.md').read_bytes()).hexdigest(),
    source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources},
    acceptance=dict(
        final_windows_affected=junit(run/'final-affected.xml'),
        packet_index_and_evaluator_bundle=junit(run/'index-bundle-corrected.xml'),
        moving_metadata=junit(run/'metadata-focused.xml'),
        linux_alias_matrix=junit(root/'runs/ignition-roots-20260908/linux/final/linux-root-admission.xml'),
        mutations=dict(canonical=3,ignition=5,caught=8,survivors=0,budget_s_each=120),
        independent_public_door=dict(passed=17,windows_symlink_privilege_unmeasured=1),
        changed_sources_during_final_run=final['changed_source_files']),
    retained_negative_evidence=[
        'Unchanged legacy F5 late/dirty baseline and new A/P red baselines.',
        'First affected run:234passed,1obsolete crash-restart message assertion failed,10skipped; exact targeted row then full affected suite rerun.',
        'Linux small tmpfs free-space prerequisite failure and preexisting contains-prose mismatch; exact bf69 mismatch reproduced before test-only clarification.',
        'Two discarded mutation path-proof assertions; retained second proof shows actual sandbox import. ADMINI~1 versus Administrator expected-path normalization corrected; initial import hypothesis superseded.',
        'Initial metadata command named absent test_ignition_evaluator_bundle.py and collected no tests; actual test_ignition_bundle.py selection passed62. A subsequent unrelated rg missing-workflow-path exit was not a pytest failure.',
    ],
    limits=[
        'Entry-time admission; no handle-anchored or concurrent replacement guarantee.',
        'Known receipt output hardlink check, not a recursive arbitrary old-store hardlink audit.',
        'No same-attempt restart, negative-evidence retention, candidate promotion, Gate1 closure or release claim.',
        'Automatic temporary parent configuration is authoritative; invalid roots refuse without relocation.',
    ],artifacts=[])
for label,folder in [('admission',run),('canonical',root/'runs/ignition-roots-20260908')]:
    for path in sorted(folder.rglob('*')):
        if not path.is_file():
            continue
        assert path.suffix!='.py',path
        blob=path.read_bytes()
        name=label+'--'+'--'.join(path.relative_to(folder).parts)+'.gz'
        packed=gzip.compress(blob,mtime=0)
        (out/name).write_bytes(packed)
        assert path.read_bytes()==blob,path
        manifest['artifacts'].append(dict(source=str(path.relative_to(root)).replace('\\','/'),
            sha256=hashlib.sha256(blob).hexdigest(),archive=name,archive_sha256=hashlib.sha256(packed).hexdigest()))
for name,path in [('root-mutation-harness',Path(__file__).with_name('g1-root-mutations.py')),
                  ('evidence-archive-harness',Path(__file__))]:
    blob=path.read_bytes();packed=gzip.compress(blob,mtime=0);archive=name+'.py.gz'
    (out/archive).write_bytes(packed)
    manifest['artifacts'].append(dict(source=str(path),sha256=hashlib.sha256(blob).hexdigest(),archive=archive,archive_sha256=hashlib.sha256(packed).hexdigest()))
for artifact in manifest['artifacts']:
    blob=(out/artifact['archive']).read_bytes()
    assert hashlib.sha256(blob).hexdigest()==artifact['archive_sha256']
    assert hashlib.sha256(gzip.decompress(blob)).hexdigest()==artifact['sha256']
(out/'acceptance.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(archives=len(manifest['artifacts']),acceptance=manifest['acceptance']),indent=2))
