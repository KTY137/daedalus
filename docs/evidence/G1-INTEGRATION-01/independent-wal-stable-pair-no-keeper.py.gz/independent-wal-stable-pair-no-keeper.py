﻿"""Independent read-only review probe, temporary SQLite artifacts only."""
import hashlib
import json
import pathlib
import shutil
import sqlite3
import tempfile
from datetime import datetime, timezone
from daedalus.spine.ledger import SpineLedger
from daedalus.kernel.attempt_spine_reader import read_attempt_intents, _existing_wal_is_live

print(json.dumps({'sqlite_version':sqlite3.sqlite_version,'reader_source_sha256':hashlib.sha256(pathlib.Path('daedalus/kernel/attempt_spine_reader.py').read_bytes()).hexdigest()}))
with tempfile.TemporaryDirectory(prefix='daedalus-wal-review-') as tmp:
    base = pathlib.Path(tmp)
    live = SpineLedger(base / 'live' / 'spine.sqlite3')
    live._conn.execute('PRAGMA wal_autocheckpoint=0')
    intent = live.record_intent('attempt.lifecycle', {'start': {'started_at': datetime.now(timezone.utc).isoformat()}}, effect_key='attempt-lifecycle:review')
    try:
        copied = base / 'copied'
        copied.mkdir()
        database = copied / 'spine.sqlite3'
        for suffix in ('', '-wal', '-shm'):
            shutil.copyfile(str(live.path) + suffix, str(database) + suffix)
        before = {p.name: p.read_bytes() for p in copied.iterdir()}
        admitted = _existing_wal_is_live(database)
        assert admitted
        rows = read_attempt_intents(database, existing_wal=True)
        assert [row.id for row in rows] == [intent.id]
        after = {p.name: p.read_bytes() for p in copied.iterdir()}
        assert set(before) == set(after)
        observations = {}
        for name in before:
            old, new = before[name], after[name]
            differences = [i for i, (a, b) in enumerate(zip(old, new)) if a != b]
            observations[name] = {'before_length':len(old),'after_length':len(new),'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),'changed_offsets':differences}
        assert before['spine.sqlite3'] == after['spine.sqlite3']
        assert before['spine.sqlite3-wal'] == after['spine.sqlite3-wal']
        outside_readmarks = [i for i in observations['spine.sqlite3-shm']['changed_offsets'] if not 100 <= i < 120]
        assert outside_readmarks, 'This SQLite build did not reproduce SHM reconstruction'
        print(json.dumps({'preexisting_valid_pair_admitted':admitted,'copied_database_has_no_other_connection':True,'reader_result':[{'id':row.id,'state':row.state} for row in rows],'file_set_unchanged':True,'sidecars_stable_during_read':True,'changes_outside_shm_readmarks':outside_readmarks,'files':observations},sort_keys=True))
        print('REPRODUCED: a stable existing pair alone does not imply read-mark-only SHM mutation; DB/WAL and file set remained unchanged.')
    finally:
        live.close()
