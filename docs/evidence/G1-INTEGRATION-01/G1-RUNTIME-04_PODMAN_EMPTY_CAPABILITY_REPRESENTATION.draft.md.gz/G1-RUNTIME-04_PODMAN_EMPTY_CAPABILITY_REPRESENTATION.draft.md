# G1-RUNTIME-04 - Podman empty capability representation

Packet ID: `G1-RUNTIME-04`
Artifact role: `draft` (local frozen proposal; not registered or primary)
Active gate: `1`
Classification: `ALIGNED`
Owner: `repository owner`
Base revision: `eb7834d52949ad10b2bb8c51fccd2a81c48aab20`
Dependencies: `Master Plan Revision 13; G1-INTEGRATION-01; existing Linux OCI containment boundary`
Freeze: `2026-09-08`, before production or test edits.

## Conditional acceptance claim

If retained raw output from the unchanged canonical Podman inspection confirms
explicit null EffectiveCaps and BoundingCaps, accept that documented empty Go
slice representation at the existing capability admission check. Both resolved
sets must still be empty. Missing fields, nonempty sets, and malformed values
refuse before candidate start. A real contained probe must independently observe
zero effective and bounding capability masks and NoNewPrivs=1 in its own procfs
status. This is runtime compatibility evidence, not scientific Gate closure or
release acceptance.

Implementation is conditional on the exact raw CI observation, independent
review, and root's go-ahead. No source/test edits are authorized by this draft.
The proposed ID was absent from docs/work-packets/index.json at the base above.
Root owns any later primary metadata, index, corpus pins, and commit integration.

## Existing failure and source evidence

On the preceding 7d23 integration head, Linux Python 3.10 and 3.12 live OCI
preflight reached _verify_container and refused its EffectiveCaps/BoundingCaps
comparison to []. Existing artifacts do not expose the full candidate inspection
or those raw fields; their values remain unknown at this freeze. The earlier
seccomp package metadata refusal was separately reproduced and corrected by
exact-version authenticated package restoration (mode777 to644, same bytes).
That provisioning result does not establish capability state.

Upstream Podman v4.9.3 supports the conditional hypothesis:

- pkg/specgen/generate/security_linux.go79-108 starts caplist as a nil []string,
  appending only surviving capabilities;147 assigns it to Bounding. For a
  nonroot user with no additions,166-173 assigns a nil userCaps to Effective.
- libpod/container_inspect.go175-178 copies those OCI capability slices directly.
- libpod/define/container_inspect.go662-663 declares []string JSON fields without
  omitempty. Go encoding/json encodes nil slices as JSON null.

Primary source links:
https://github.com/containers/podman/blob/v4.9.3/pkg/specgen/generate/security_linux.go#L78-L178
https://github.com/containers/podman/blob/v4.9.3/libpod/container_inspect.go#L175-L178
https://github.com/containers/podman/blob/v4.9.3/libpod/define/container_inspect.go#L662-L663
https://pkg.go.dev/encoding/json#Marshal
https://man7.org/linux/man-pages/man5/proc_pid_status.5.html

Source inference is distinct from the pending observed candidate metadata.

## Scope and canonical ownership

Production: daedalus/spine/linux_containment.py::_verify_container, limited to
reading the two existing capability fields. Use local missing-field distinction;
do not broaden _ci_get or _empty globally. Normalize only the explicit null or
empty JSON array representation into the existing empty capability facts.

Tests: tests/test_linux_oci_containment.py, extending existing admission and
create/inspect/start/cleanup coverage and the existing single real OCI probe.
No new module, helper subsystem, schema, event store, evidence authority, or
runtime path. Root-owned CI capture may retain exact inspect/procfs observations
without changing the test outcome or weakening admission.

Unchanged: --cap-drop=all, no-new-privileges request and verification, trusted
runtime paths, rootless mapping, package/seccomp checks, image digest admission,
mount/network/resource checks, immutable OCI identity, create-inspect-start
ordering, strict cleanup, containment attestation schema, and policy/evaluator.
No candidate fallback on the host, no retry, no provider launch, no release or
promotion, and no Master Plan amendment.

## Frozen regression matrix

A1. Retain raw JSON from the unchanged canonical create/inspect seam and the
original failure in each available Linux matrix lane. Record exact source head,
Podman version, image digest, field presence, field values, and JSON types.
If either capability set is actually nonempty, missing, or malformed, stop this
codec correction and report the real boundary failure; do not normalize it away.

A2. On the unchanged source, add meaningful positive cases []/[], null/[],
[]/null, and null/null for EffectiveCaps/BoundingCaps. Preserve the [] baseline;
retain the null-case failures before the production change. Each accepted case
must produce the same existing empty capability facts; no raw null leaks into a
new contract or weakens another field.

A3. For each field separately, refuse missing, empty object, empty string,
boolean false/true, numeric zero, nonempty capability list, and malformed array
members such as null. Exercise mixed pairs so an empty field cannot hide an
unsafe other field. Retain existing case-insensitive lookup behavior; do not
invent alternate schemas or accept strings naming empty values.

A4. Through spawn_oci_contained, not only direct verifier calls, malformed,
missing, and nonempty capability inspection must never reach subprocess.Popen.
Verify the canonical removal of the exact created container and hooks cleanup.
Do not replace production cleanup with a fake successful result under review;
controlled subprocess doubles test ordering only and are explicitly scoped.

A5. Extend the existing live test
 test_live_linux_container_writes_workspace_but_not_root_and_has_no_network
in place. Within that actual contained Python process read /proc/self/status,
retain the exact CapEff, CapBnd and NoNewPrivs strings, and expose them through
the existing captured output. Parent-side assertions must require all fields,
parse hexadecimal capability masks, and require exactly zero for both; require
NoNewPrivs exactly 1. Missing/unparseable/nonzero observations fail. Retain actual
workspace write, refused root write, refused network and exit-success assertions.
Keep this as one unskipped live test, preserving its existing opt-in requirement.
The fixed probe is measurement code, not candidate-supplied evidence authority.
Retain the captured procfs observation in the CI evidence/JUnit without making
successful stdout alone an attestation; the host assertions decide the result.

A6. Run the full focused tests/test_linux_oci_containment.py and relevant existing
containment/admission contract checks once source is frozen. Real Windows runs
will skip the Linux live test and cannot close A5. Require the actual existing
Linux Python3.10/3.12 CI matrix to produce one unskipped live pass each, including
the independent procfs assertions, then run the unchanged real HTTP Genesis
suite against that admitted runtime. The host Python matrix does not imply two
different interpreters inside the single pinned OCI image.

A7. Retain all preceding negative CI evidence and red tests with source identity;
append measured green results and independent review without rewriting prior
claims. Actual Linux OCI acceptance remains pending until observed. The known
Linux full-GUI release-only gap remains separate and no tagged-release claim is
made. Root decides proportional full integration reruns and corpus repins.

## Rollback and limits

No migration. Reverting the bounded decoder change restores explicit-null
refusal. This packet proves the specified running probe on the measured runtime
and image; it is not a universal Linux security guarantee or a new capability
policy. Kernel checks remain the canonical production admission boundary.
